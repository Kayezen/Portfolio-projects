import javax.swing.*;
import java.awt.*;
import java.util.List;
import java.util.ArrayList;

/**
 * Draws the StudentBST as a tree diagram (circles connected by lines),
 * similar to a textbook BST picture. Each node shows the student's roll number.
 *
 * HOW TO USE (see instructions below for wiring into Mainframev2):
 *   BSTVisualizerPanel panel = new BSTVisualizerPanel(tree);
 *   panel.refreshTree(tree); // call this again whenever the tree changes
 */
public class BSTVisualizerPanel extends JPanel {

    // simple internal copy of node positions so we know where to draw circles/lines
    private static class DrawNode {
        int rollNumber;
        int x, y;
        DrawNode left, right;
    }

    private DrawNode drawRoot;
    private static final int NODE_RADIUS = 22;
    private static final int VERTICAL_GAP = 80;

    public BSTVisualizerPanel(StudentBST tree) {
        setBackground(Color.WHITE);
        setPreferredSize(new Dimension(700, 450));
        refreshTree(tree);
    }

    // Call this every time the BST changes (after add/delete) to redraw
    public void refreshTree(StudentBST tree) {
        StudentBST.Node root = (tree == null) ? null : tree.getRoot();
        drawRoot = buildDrawTree(root);
        assignPositions();
        repaint();
    }

    // Converts the real BST into a lightweight tree just for drawing
    private DrawNode buildDrawTree(StudentBST.Node node) {
        if (node == null) return null;
        DrawNode d = new DrawNode();
        d.rollNumber = node.rollNumber;
        d.left = buildDrawTree(node.left);
        d.right = buildDrawTree(node.right);
        return d;
    }

    // Assigns x,y coordinates to every node so it renders like the sample picture.
    // x position comes from inorder traversal order (left to right on screen).
    // y position comes from depth (root at top).
    private int nextX;

    private void assignPositions() {
        nextX = 60;
        assignPositionsRec(drawRoot, 0);
    }

    private void assignPositionsRec(DrawNode node, int depth) {
        if (node == null) return;
        assignPositionsRec(node.left, depth + 1);

        node.x = nextX;
        node.y = 50 + depth * VERTICAL_GAP;
        nextX += 70;

        assignPositionsRec(node.right, depth + 1);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        g2.setFont(new Font("Segoe UI", Font.BOLD, 14));
        g2.drawString("Binary Search Tree", getWidth() / 2 - 60, 25);

        if (drawRoot == null) {
            g2.drawString("No students yet", getWidth() / 2 - 50, getHeight() / 2);
            return;
        }

        drawEdges(g2, drawRoot);
        drawNodes(g2, drawRoot);
    }

    // draws the connecting lines first so circles sit on top
    private void drawEdges(Graphics2D g2, DrawNode node) {
        if (node == null) return;
        g2.setColor(Color.DARK_GRAY);
        if (node.left != null) {
            g2.drawLine(node.x, node.y, node.left.x, node.left.y);
            drawEdges(g2, node.left);
        }
        if (node.right != null) {
            g2.drawLine(node.x, node.y, node.right.x, node.right.y);
            drawEdges(g2, node.right);
        }
    }

    // draws the circles with roll numbers inside
    private void drawNodes(Graphics2D g2, DrawNode node) {
        if (node == null) return;

        g2.setColor(new Color(198, 224, 198)); // light green like the sample image
        g2.fillOval(node.x - NODE_RADIUS, node.y - NODE_RADIUS, NODE_RADIUS * 2, NODE_RADIUS * 2);
        g2.setColor(Color.BLACK);
        g2.drawOval(node.x - NODE_RADIUS, node.y - NODE_RADIUS, NODE_RADIUS * 2, NODE_RADIUS * 2);

        String text = String.valueOf(node.rollNumber);
        FontMetrics fm = g2.getFontMetrics();
        int textWidth = fm.stringWidth(text);
        g2.drawString(text, node.x - textWidth / 2, node.y + fm.getAscent() / 2 - 2);

        drawNodes(g2, node.left);
        drawNodes(g2, node.right);
    }
}

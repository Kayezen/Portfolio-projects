# Student Records Management System (Java Swing + BST)

## How to compile and run

From the `src` folder:

```
javac App.java logic/*.java gui/*.java
java App
```

Or in an IDE (IntelliJ/Eclipse/NetBeans): mark `src` as the source root and run `App.java`.

## Structure

- `logic/` — pure data layer, no Swing code
  - `Student.java` — a student record / BST node
  - `StudentBST.java` — Binary Search Tree: insert, delete, search, in/pre/post-order traversal
  - `StudentStore.java` — wraps the BST, tracks the last 3 added students for the dashboard
- `gui/` — pure Swing UI, talks to `logic` only through `StudentStore`
  - `MainFrame.java` — main window, screen switching
  - `Sidebar.java` — left navigation
  - `DashboardPanel.java`, `RecordsPanel.java`, `AddStudentPanel.java` — the three screens
  - `UIStyle.java` — shared colors/fonts/components
- `App.java` — entry point, the only class that wires `logic` and `gui` together

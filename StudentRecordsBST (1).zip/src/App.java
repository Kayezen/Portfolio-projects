import gui.MainFrame;

import javax.swing.SwingUtilities;
import javax.swing.UIManager;

/**
 * Application entry point.
 *
 * This class is intentionally the only place that ties the two halves of
 * the program together:
 *   - logic/  : Student, StudentBST, StudentStore  (Binary Search Tree data layer)
 *   - gui/    : UIStyle, Sidebar, MainFrame, DashboardPanel, RecordsPanel,
 *               AddStudentPanel  (Java Swing presentation layer)
 *
 * Run this class to launch the Student Records Management System.
 */
public class App {
    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
        } catch (Exception ignored) {
            // Fall back to default look and feel if unavailable.
        }
        SwingUtilities.invokeLater(() -> new MainFrame().setVisible(true));
    }
}

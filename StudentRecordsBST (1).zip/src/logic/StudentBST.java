package logic;

import java.util.ArrayList;
import java.util.List;

/**
 * Binary Search Tree that stores Student records keyed by studentId.
 * Supports insertion, deletion, search, and in-order/pre-order/post-order
 * traversal, as required by the "Student Record Management (Using BST)"
 * specification.
 */
public class StudentBST {

    private Student root;
    private int size = 0;

    public int size() {
        return size;
    }

    // ---------- INSERTION ----------

    /** Inserts a new student. Returns false if the studentId already exists. */
    public boolean insert(String studentId, String name, String course, int grade) {
        if (search(studentId) != null) {
            return false; // duplicate roll number not allowed
        }
        root = insertRec(root, studentId, name, course, grade);
        size++;
        return true;
    }

    private Student insertRec(Student node, String id, String name, String course, int grade) {
        if (node == null) {
            return new Student(id, name, course, grade);
        }
        int cmp = id.compareTo(node.studentId);
        if (cmp < 0) {
            node.left = insertRec(node.left, id, name, course, grade);
        } else if (cmp > 0) {
            node.right = insertRec(node.right, id, name, course, grade);
        }
        return node;
    }

    // ---------- SEARCH ----------

    public Student search(String studentId) {
        return searchRec(root, studentId);
    }

    private Student searchRec(Student node, String id) {
        if (node == null) return null;
        int cmp = id.compareTo(node.studentId);
        if (cmp == 0) return node;
        return cmp < 0 ? searchRec(node.left, id) : searchRec(node.right, id);
    }

    // ---------- DELETION ----------

    public boolean delete(String studentId) {
        if (search(studentId) == null) return false;
        root = deleteRec(root, studentId);
        size--;
        return true;
    }

    private Student deleteRec(Student node, String id) {
        if (node == null) return null;

        int cmp = id.compareTo(node.studentId);
        if (cmp < 0) {
            node.left = deleteRec(node.left, id);
        } else if (cmp > 0) {
            node.right = deleteRec(node.right, id);
        } else {
            // Node found: handle 0, 1, or 2 children
            if (node.left == null) return node.right;
            if (node.right == null) return node.left;

            // Two children: replace with in-order successor (smallest in right subtree)
            Student successor = findMin(node.right);
            node.studentId = successor.studentId;
            node.name = successor.name;
            node.course = successor.course;
            node.grade = successor.grade;
            node.right = deleteRec(node.right, successor.studentId);
        }
        return node;
    }

    private Student findMin(Student node) {
        while (node.left != null) node = node.left;
        return node;
    }

    // ---------- TRAVERSALS ----------

    /** In-order traversal gives students sorted by studentId. */
    public List<Student> inorder() {
        List<Student> result = new ArrayList<>();
        inorderRec(root, result);
        return result;
    }

    private void inorderRec(Student node, List<Student> result) {
        if (node == null) return;
        inorderRec(node.left, result);
        result.add(node);
        inorderRec(node.right, result);
    }

    public List<Student> preorder() {
        List<Student> result = new ArrayList<>();
        preorderRec(root, result);
        return result;
    }

    private void preorderRec(Student node, List<Student> result) {
        if (node == null) return;
        result.add(node);
        preorderRec(node.left, result);
        preorderRec(node.right, result);
    }

    public List<Student> postorder() {
        List<Student> result = new ArrayList<>();
        postorderRec(root, result);
        return result;
    }

    private void postorderRec(Student node, List<Student> result) {
        if (node == null) return;
        postorderRec(node.left, result);
        postorderRec(node.right, result);
        result.add(node);
    }

    // ---------- STATS (used by Dashboard) ----------

    public double averageGrade() {
        List<Student> all = inorder();
        if (all.isEmpty()) return 0;
        int sum = 0;
        for (Student s : all) sum += s.grade;
        return sum / (double) all.size();
    }

    public Student topStudent() {
        List<Student> all = inorder();
        Student top = null;
        for (Student s : all) {
            if (top == null || s.grade > top.grade) top = s;
        }
        return top;
    }

    /** Returns the last N inserted students, in insertion order, by walking
     *  the tree and using a simple recency counter would require extra
     *  bookkeeping; instead we track recency with a separate list. */
}

package logic;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

/**
 * Wraps the StudentBST and keeps a simple recency queue so the Dashboard
 * can show "Recent Students - Last 3 added" without changing the BST's
 * core responsibility (sorted storage/search by studentId).
 */
public class StudentStore {

    private final StudentBST tree = new StudentBST();
    private final LinkedList<String> recentIds = new LinkedList<>();

    public boolean addStudent(String id, String name, String course, int grade) {
        boolean added = tree.insert(id, name, course, grade);
        if (added) {
            recentIds.addFirst(id);
            if (recentIds.size() > 3) recentIds.removeLast();
        }
        return added;
    }

    public boolean deleteStudent(String id) {
        boolean removed = tree.delete(id);
        if (removed) recentIds.remove(id);
        return removed;
    }

    public Student findStudent(String id) {
        return tree.search(id);
    }

    public List<Student> allStudentsSorted() {
        return tree.inorder();
    }

    public List<Student> recentStudents() {
        List<Student> result = new ArrayList<>();
        for (String id : recentIds) {
            Student s = tree.search(id);
            if (s != null) result.add(s);
        }
        return result;
    }

    public int totalStudents() {
        return tree.size();
    }

    public double averageGrade() {
        return tree.averageGrade();
    }

    public Student topStudent() {
        return tree.topStudent();
    }

    /** Loads a few sample records matching the mockup screenshots. */
    public void loadSampleData() {
        addStudent("2824081", "Juan Dela Cruz", "BS Computer Science", 89);
        addStudent("2824082", "Maria Santos", "BS Information Technology", 92);
        addStudent("2824083", "John Reyes", "BS Computer Engineering", 85);
        addStudent("2824084", "Angela Flores", "BS Computer Science", 91);
        addStudent("2824085", "Carlos Mendoza", "BS Information Technology", 78);
    }
}

package logic;

/**
 * Represents a single student record and doubles as a BST node.
 * The tree is ordered by studentId (roll number).
 */
public class Student {
    public String studentId;   // e.g. "2024081"
    public String name;
    public String course;
    public int grade;

    // Package-private: only StudentBST (same package) should touch tree links.
    Student left, right;

    public Student(String studentId, String name, String course, int grade) {
        this.studentId = studentId;
        this.name = name;
        this.course = course;
        this.grade = grade;
    }
}

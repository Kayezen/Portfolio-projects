package gui;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;

/** Central place for colors, fonts, and small UI helper builders. */
public class UIStyle {
    public static final Color BG = Color.WHITE;
    public static final Color SIDEBAR_BG = new Color(0xFA, 0xFA, 0xFB);
    public static final Color BORDER = new Color(0xE5, 0xE7, 0xEB);
    public static final Color TEXT_DARK = new Color(0x11, 0x18, 0x27);
    public static final Color TEXT_GRAY = new Color(0x6B, 0x72, 0x80);
    public static final Color BLUE = new Color(0x25, 0x63, 0xEB);
    public static final Color BLUE_LIGHT = new Color(0xEF, 0xF6, 0xFF);
    public static final Color GREEN = new Color(0x16, 0xA3, 0x4A);
    public static final Color GREEN_LIGHT = new Color(0xEC, 0xFD, 0xF3);
    public static final Color RED = new Color(0xDC, 0x26, 0x26);
    public static final Color RED_LIGHT = new Color(0xFE, 0xF2, 0xF2);
    public static final Color AMBER = new Color(0xD9, 0x77, 0x06);
    public static final Color AMBER_LIGHT = new Color(0xFF, 0xFB, 0xEB);

    public static final Font FONT_TITLE = new Font("SansSerif", Font.BOLD, 22);
    public static final Font FONT_SUBTITLE = new Font("SansSerif", Font.PLAIN, 13);
    public static final Font FONT_LABEL = new Font("SansSerif", Font.BOLD, 11);
    public static final Font FONT_BODY = new Font("SansSerif", Font.PLAIN, 13);
    public static final Font FONT_BODY_BOLD = new Font("SansSerif", Font.BOLD, 13);
    public static final Font FONT_BIG_NUMBER = new Font("SansSerif", Font.BOLD, 28);
    public static final Font FONT_NAV = new Font("SansSerif", Font.PLAIN, 13);

    public static JPanel card() {
        JPanel p = new JPanel();
        p.setBackground(BG);
        p.setBorder(new CompoundBorder(
                new LineBorder(BORDER, 1, true),
                new EmptyBorder(16, 16, 16, 16)));
        return p;
    }

    public static JButton primaryButton(String text) {
        JButton b = new JButton(text);
        b.setBackground(BLUE);
        b.setForeground(Color.WHITE);
        b.setFont(FONT_BODY_BOLD);
        b.setFocusPainted(false);
        b.setBorder(new EmptyBorder(9, 18, 9, 18));
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return b;
    }

    public static JButton secondaryButton(String text) {
        JButton b = new JButton(text);
        b.setBackground(Color.WHITE);
        b.setForeground(TEXT_DARK);
        b.setFont(FONT_BODY_BOLD);
        b.setFocusPainted(false);
        b.setBorder(new CompoundBorder(new LineBorder(BORDER, 1, true), new EmptyBorder(8, 17, 8, 17)));
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return b;
    }

    public static JButton linkButton(String text, Color color) {
        JButton b = new JButton(text);
        b.setForeground(color);
        b.setFont(FONT_BODY_BOLD);
        b.setBorderPainted(false);
        b.setContentAreaFilled(false);
        b.setFocusPainted(false);
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return b;
    }

    public static JLabel pill(String text, Color fg, Color bg) {
        JLabel l = new JLabel(text, SwingConstants.CENTER);
        l.setOpaque(true);
        l.setBackground(bg);
        l.setForeground(fg);
        l.setFont(FONT_BODY_BOLD);
        l.setBorder(new EmptyBorder(3, 10, 3, 10));
        return l;
    }

    public static Color gradeColor(int grade) {
        if (grade >= 90) return GREEN;
        if (grade >= 80) return BLUE;
        return AMBER;
    }

    public static Color gradeColorBg(int grade) {
        if (grade >= 90) return GREEN_LIGHT;
        if (grade >= 80) return BLUE_LIGHT;
        return AMBER_LIGHT;
    }

    public static String initials(String name) {
        String[] parts = name.trim().split("\\s+");
        StringBuilder sb = new StringBuilder();
        for (String p : parts) {
            if (!p.isEmpty()) sb.append(Character.toUpperCase(p.charAt(0)));
            if (sb.length() >= 2) break;
        }
        return sb.toString();
    }

    public static JLabel avatar(String name) {
        JLabel l = new JLabel(initials(name), SwingConstants.CENTER) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(BLUE_LIGHT);
                g2.fillOval(0, 0, getWidth(), getHeight());
                g2.dispose();
                super.paintComponent(g);
            }
        };
        l.setForeground(BLUE);
        l.setFont(FONT_BODY_BOLD);
        l.setPreferredSize(new Dimension(36, 36));
        return l;
    }
}

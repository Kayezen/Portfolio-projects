package gui;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

/**
 * Left navigation sidebar shown on every screen: Dashboard, Student Records,
 * Add Student.
 */
public class Sidebar extends JPanel {

    public interface NavListener {
        void onNavigate(String screen);
    }

    private final NavListener listener;
    private final String active;

    public Sidebar(String activeScreen, NavListener listener) {
        this.listener = listener;
        this.active = activeScreen;

        setLayout(new BorderLayout());
        setBackground(UIStyle.SIDEBAR_BG);
        setPreferredSize(new Dimension(220, 0));
        setBorder(new EmptyBorder(0, 0, 0, 0));

        JPanel top = new JPanel();
        top.setLayout(new BoxLayout(top, BoxLayout.Y_AXIS));
        top.setBackground(UIStyle.SIDEBAR_BG);
        top.setBorder(new EmptyBorder(20, 16, 20, 16));

        top.add(buildHeader());
        top.add(Box.createVerticalStrut(24));
        top.add(sectionLabel("MENU"));
        top.add(Box.createVerticalStrut(6));
        top.add(navItem("Dashboard", "DASHBOARD"));
        top.add(navItem("Student Records", "RECORDS"));
        top.add(navItem("Add Student", "ADD"));

        add(top, BorderLayout.NORTH);

        JLabel footer = new JLabel("SRMS  \u00B7  Data Structures");
        footer.setFont(new Font("SansSerif", Font.PLAIN, 10));
        footer.setForeground(UIStyle.TEXT_GRAY);
        footer.setBorder(new EmptyBorder(10, 16, 10, 16));
        add(footer, BorderLayout.SOUTH);

        // right border line
        setBorder(BorderFactory.createMatteBorder(0, 0, 0, 1, UIStyle.BORDER));
    }

    private JPanel buildHeader() {
        JPanel header = new JPanel(new BorderLayout(10, 0));
        header.setBackground(UIStyle.SIDEBAR_BG);
        header.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel icon = new JLabel("\uD83C\uDF93"); // graduation cap emoji as simple icon
        icon.setOpaque(true);
        icon.setBackground(UIStyle.BLUE);
        icon.setHorizontalAlignment(SwingConstants.CENTER);
        icon.setPreferredSize(new Dimension(34, 34));
        icon.setFont(new Font("SansSerif", Font.PLAIN, 16));

        JPanel textPanel = new JPanel();
        textPanel.setLayout(new BoxLayout(textPanel, BoxLayout.Y_AXIS));
        textPanel.setBackground(UIStyle.SIDEBAR_BG);
        JLabel title = new JLabel("Student Records");
        title.setFont(UIStyle.FONT_BODY_BOLD);
        title.setForeground(UIStyle.TEXT_DARK);
        JLabel subtitle = new JLabel("Management System");
        subtitle.setFont(new Font("SansSerif", Font.PLAIN, 10));
        subtitle.setForeground(UIStyle.TEXT_GRAY);
        textPanel.add(title);
        textPanel.add(subtitle);

        header.add(icon, BorderLayout.WEST);
        header.add(textPanel, BorderLayout.CENTER);
        header.setMaximumSize(new Dimension(220, 40));
        return header;
    }

    private JLabel sectionLabel(String text) {
        JLabel l = new JLabel(text);
        l.setFont(UIStyle.FONT_LABEL);
        l.setForeground(UIStyle.TEXT_GRAY);
        l.setAlignmentX(Component.LEFT_ALIGNMENT);
        l.setBorder(new EmptyBorder(0, 4, 0, 0));
        return l;
    }

    private JComponent navItem(String label, String screenKey) {
        boolean isActive = screenKey.equals(active);

        JPanel item = new JPanel(new BorderLayout());
        item.setAlignmentX(Component.LEFT_ALIGNMENT);
        item.setMaximumSize(new Dimension(300, 38));
        item.setBackground(isActive ? UIStyle.BLUE_LIGHT : UIStyle.SIDEBAR_BG);
        item.setBorder(new EmptyBorder(8, 10, 8, 10));
        item.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        JLabel text = new JLabel(label);
        text.setFont(isActive ? UIStyle.FONT_BODY_BOLD : UIStyle.FONT_NAV);
        text.setForeground(isActive ? UIStyle.BLUE : UIStyle.TEXT_DARK);
        item.add(text, BorderLayout.WEST);

        if (isActive) {
            JLabel dot = new JLabel("\u25CF");
            dot.setForeground(UIStyle.BLUE);
            dot.setFont(new Font("SansSerif", Font.PLAIN, 8));
            item.add(dot, BorderLayout.EAST);
        }

        item.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (listener != null) listener.onNavigate(screenKey);
            }

            @Override
            public void mouseEntered(MouseEvent e) {
                if (!isActive) item.setBackground(new Color(0xF0, 0xF1, 0xF3));
            }

            @Override
            public void mouseExited(MouseEvent e) {
                if (!isActive) item.setBackground(UIStyle.SIDEBAR_BG);
            }
        });

        JPanel wrapper = new JPanel(new BorderLayout());
        wrapper.setAlignmentX(Component.LEFT_ALIGNMENT);
        wrapper.setMaximumSize(new Dimension(300, 42));
        wrapper.setBackground(UIStyle.SIDEBAR_BG);
        wrapper.setBorder(new EmptyBorder(2, 0, 2, 0));
        wrapper.add(item, BorderLayout.CENTER);
        return wrapper;
    }
}

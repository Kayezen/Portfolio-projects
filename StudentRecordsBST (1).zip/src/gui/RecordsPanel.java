package gui;

import logic.Student;
import logic.StudentStore;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.AbstractTableModel;
import java.awt.*;
import java.util.List;

/**
 * Student Records screen: displays all students (in-order BST traversal,
 * i.e. sorted by Student ID), with search-by-name/ID, View, and Delete.
 */
public class RecordsPanel extends JPanel implements MainFrame.Refreshable {

    private final MainFrame frame;
    private final StudentStore store;
    private final JTextField searchField;
    private final RecordsTableModel tableModel;
    private final JTable table;
    private final JLabel countLabel;

    public RecordsPanel(MainFrame frame, StudentStore store) {
        this.frame = frame;
        this.store = store;

        setLayout(new BorderLayout());
        setBackground(UIStyle.BG);
        setBorder(new EmptyBorder(28, 32, 28, 32));

        // ---- Header ----
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(UIStyle.BG);

        JPanel titleBlock = new JPanel();
        titleBlock.setLayout(new BoxLayout(titleBlock, BoxLayout.Y_AXIS));
        titleBlock.setBackground(UIStyle.BG);
        JLabel title = new JLabel("Student Records");
        title.setFont(UIStyle.FONT_TITLE);
        title.setForeground(UIStyle.TEXT_DARK);
        JLabel subtitle = new JLabel("Manage student information");
        subtitle.setFont(UIStyle.FONT_SUBTITLE);
        subtitle.setForeground(UIStyle.TEXT_GRAY);
        titleBlock.add(title);
        titleBlock.add(Box.createVerticalStrut(4));
        titleBlock.add(subtitle);

        JButton addBtn = UIStyle.primaryButton("+ Add Student");
        addBtn.addActionListener(e -> frame.navigate(MainFrame.ADD));

        header.add(titleBlock, BorderLayout.WEST);
        header.add(addBtn, BorderLayout.EAST);
        header.setBorder(new EmptyBorder(0, 0, 20, 0));

        // ---- Search ----
        searchField = new JTextField();
        searchField.setBorder(new CompoundEmptyBorder());
        JPanel searchWrapper = new JPanel(new BorderLayout());
        searchWrapper.setBackground(UIStyle.BG);
        searchWrapper.setBorder(BorderFactory.createCompoundBorder(
                new javax.swing.border.LineBorder(UIStyle.BORDER, 1, true),
                new EmptyBorder(6, 10, 6, 10)));
        JLabel searchIcon = new JLabel("\uD83D\uDD0D ");
        searchWrapper.add(searchIcon, BorderLayout.WEST);
        searchWrapper.add(searchField, BorderLayout.CENTER);
        searchField.putClientProperty("JTextField.placeholderText", "Search student...");
        searchField.setBorder(null);
        searchField.setFont(UIStyle.FONT_BODY);
        searchField.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
            public void insertUpdate(javax.swing.event.DocumentEvent e) { applyFilter(); }
            public void removeUpdate(javax.swing.event.DocumentEvent e) { applyFilter(); }
            public void changedUpdate(javax.swing.event.DocumentEvent e) { applyFilter(); }
        });

        JPanel searchRow = new JPanel(new BorderLayout());
        searchRow.setBackground(UIStyle.BG);
        searchRow.setBorder(new EmptyBorder(0, 0, 14, 0));
        JPanel searchBox = new JPanel(new BorderLayout());
        searchBox.setPreferredSize(new Dimension(280, 34));
        searchBox.setBackground(UIStyle.BG);
        searchBox.add(searchWrapper, BorderLayout.CENTER);
        searchRow.add(searchBox, BorderLayout.WEST);

        // ---- Table ----
        tableModel = new RecordsTableModel();
        table = new JTable(tableModel);
        table.setRowHeight(44);
        table.setShowGrid(false);
        table.setIntercellSpacing(new Dimension(0, 0));
        table.setFont(UIStyle.FONT_BODY);
        table.getTableHeader().setFont(UIStyle.FONT_LABEL);
        table.getTableHeader().setForeground(UIStyle.TEXT_GRAY);
        table.getTableHeader().setBackground(UIStyle.BG);
        table.getTableHeader().setPreferredSize(new Dimension(0, 34));
        table.setSelectionBackground(new Color(0xF5, 0xF7, 0xFA));
        table.setSelectionForeground(UIStyle.TEXT_DARK);

        table.getColumnModel().getColumn(1).setCellRenderer(new NameCellRenderer());
        table.getColumnModel().getColumn(3).setCellRenderer(new GradeCellRenderer());
        table.getColumnModel().getColumn(4).setCellRenderer(new ActionsCellRenderer());
        table.getColumnModel().getColumn(4).setCellEditor(
                new ActionsCellEditor(this::onView, this::onDelete));

        table.getColumnModel().getColumn(0).setPreferredWidth(90);
        table.getColumnModel().getColumn(1).setPreferredWidth(220);
        table.getColumnModel().getColumn(2).setPreferredWidth(200);
        table.getColumnModel().getColumn(3).setPreferredWidth(80);
        table.getColumnModel().getColumn(4).setPreferredWidth(150);

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBorder(new javax.swing.border.LineBorder(UIStyle.BORDER, 1, true));
        scrollPane.getViewport().setBackground(UIStyle.BG);

        countLabel = new JLabel();
        countLabel.setFont(new Font("SansSerif", Font.PLAIN, 11));
        countLabel.setForeground(UIStyle.TEXT_GRAY);
        countLabel.setBorder(new EmptyBorder(8, 2, 0, 0));

        JPanel tableCard = new JPanel(new BorderLayout());
        tableCard.setBackground(UIStyle.BG);
        tableCard.add(scrollPane, BorderLayout.CENTER);
        tableCard.add(countLabel, BorderLayout.SOUTH);

        JPanel centerStack = new JPanel(new BorderLayout());
        centerStack.setBackground(UIStyle.BG);
        centerStack.add(searchRow, BorderLayout.NORTH);
        centerStack.add(tableCard, BorderLayout.CENTER);

        add(header, BorderLayout.NORTH);
        add(centerStack, BorderLayout.CENTER);

        refresh();
    }

    @Override
    public void refresh() {
        searchField.setText("");
        applyFilter();
    }

    private void applyFilter() {
        String query = searchField.getText().trim().toLowerCase();
        List<Student> all = store.allStudentsSorted(); // BST in-order traversal
        List<Student> filtered = all.stream()
                .filter(s -> query.isEmpty()
                        || s.name.toLowerCase().contains(query)
                        || s.studentId.toLowerCase().contains(query)
                        || s.course.toLowerCase().contains(query))
                .toList();
        tableModel.setData(filtered);
        countLabel.setText(filtered.size() + (filtered.size() == 1 ? " student found" : " students found"));
    }

    private void onView(Student s) {
        String message = "Student ID: " + s.studentId
                + "\nName: " + s.name
                + "\nCourse: " + s.course
                + "\nGrade: " + s.grade;
        JOptionPane.showMessageDialog(this, message, "Student Details", JOptionPane.INFORMATION_MESSAGE);
    }

    private void onDelete(Student s) {
        int confirm = JOptionPane.showConfirmDialog(this,
                "Delete record for " + s.name + " (" + s.studentId + ")?",
                "Confirm Delete", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
        if (confirm == JOptionPane.YES_OPTION) {
            store.deleteStudent(s.studentId);
            applyFilter();
        }
    }

    // A borderless empty border helper to keep JTextField flat inside the search box.
    private static class CompoundEmptyBorder extends EmptyBorder {
        CompoundEmptyBorder() { super(0, 0, 0, 0); }
    }

    // ---------- Table model ----------
    static class RecordsTableModel extends AbstractTableModel {
        private final String[] columns = {"STUDENT ID", "NAME", "COURSE", "GRADE", "ACTIONS"};
        private List<Student> data = List.of();

        void setData(List<Student> data) {
            this.data = data;
            fireTableDataChanged();
        }

        @Override public int getRowCount() { return data.size(); }
        @Override public int getColumnCount() { return columns.length; }
        @Override public String getColumnName(int col) { return columns[col]; }

        @Override
        public Object getValueAt(int row, int col) {
            Student s = data.get(row);
            return switch (col) {
                case 0 -> s.studentId;
                case 1 -> s;
                case 2 -> s.course;
                case 3 -> s.grade;
                case 4 -> s;
                default -> null;
            };
        }

        @Override
        public boolean isCellEditable(int row, int col) {
            return col == 4;
        }

        Student getStudentAt(int row) {
            return data.get(row);
        }
    }

    // ---------- Cell renderers ----------
    static class NameCellRenderer extends JPanel implements javax.swing.table.TableCellRenderer {
        private final JLabel avatar = new JLabel();
        private final JLabel nameLabel = new JLabel();

        NameCellRenderer() {
            setLayout(new BorderLayout(10, 0));
            setBorder(new EmptyBorder(4, 8, 4, 8));
            nameLabel.setFont(UIStyle.FONT_BODY_BOLD);
        }

        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
                                                         boolean hasFocus, int row, int col) {
            removeAll();
            Student s = (Student) value;
            setBackground(isSelected ? table.getSelectionBackground() : UIStyle.BG);
            JLabel av = UIStyle.avatar(s.name);
            nameLabel.setText(s.name);
            add(av, BorderLayout.WEST);
            add(nameLabel, BorderLayout.CENTER);
            return this;
        }
    }

    static class GradeCellRenderer extends JLabel implements javax.swing.table.TableCellRenderer {
        GradeCellRenderer() {
            setHorizontalAlignment(SwingConstants.CENTER);
            setOpaque(true);
            setFont(UIStyle.FONT_BODY_BOLD);
        }

        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
                                                         boolean hasFocus, int row, int col) {
            int grade = (Integer) value;
            setText(String.valueOf(grade));
            setForeground(UIStyle.gradeColor(grade));
            setBackground(UIStyle.gradeColorBg(grade));
            JPanel wrapper = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
            wrapper.setBackground(isSelected ? table.getSelectionBackground() : UIStyle.BG);
            setBorder(new EmptyBorder(4, 10, 4, 10));
            wrapper.add(this);
            wrapper.setBorder(new EmptyBorder(4, 8, 4, 0));
            return wrapper;
        }
    }

    interface RowAction { void run(Student s); }

    static class ActionsCellRenderer extends JPanel implements javax.swing.table.TableCellRenderer {
        ActionsCellRenderer() {
            setLayout(new FlowLayout(FlowLayout.LEFT, 8, 4));
        }

        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
                                                         boolean hasFocus, int row, int col) {
            removeAll();
            setBackground(isSelected ? table.getSelectionBackground() : UIStyle.BG);
            JButton view = UIStyle.linkButton("View", UIStyle.BLUE);
            JButton delete = UIStyle.linkButton("Delete", UIStyle.RED);
            add(view);
            add(delete);
            return this;
        }
    }

    static class ActionsCellEditor extends AbstractCellEditorWithButtons {
        ActionsCellEditor(RowAction onView, RowAction onDelete) {
            super(onView, onDelete);
        }
    }

    /** Editor that renders View/Delete buttons and fires callbacks with the row's Student. */
    static class AbstractCellEditorWithButtons extends javax.swing.AbstractCellEditor
            implements javax.swing.table.TableCellEditor {
        private final JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 4));
        private Student current;

        AbstractCellEditorWithButtons(RowAction onView, RowAction onDelete) {
            JButton view = UIStyle.linkButton("View", UIStyle.BLUE);
            JButton delete = UIStyle.linkButton("Delete", UIStyle.RED);
            view.addActionListener(e -> {
                fireEditingStopped();
                if (current != null) onView.run(current);
            });
            delete.addActionListener(e -> {
                fireEditingStopped();
                if (current != null) onDelete.run(current);
            });
            panel.add(view);
            panel.add(delete);
        }

        @Override
        public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected,
                                                       int row, int col) {
            current = (Student) value;
            panel.setBackground(UIStyle.BG);
            return panel;
        }

        @Override
        public Object getCellEditorValue() {
            return current;
        }
    }
}

package gui;

import logic.StudentStore;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.awt.*;

/** Add Student screen: form on the left, live preview + info box on the right. */
public class AddStudentPanel extends JPanel implements MainFrame.Refreshable {

    private final MainFrame frame;
    private final StudentStore store;

    private final JTextField idField = new JTextField();
    private final JTextField nameField = new JTextField();
    private final JTextField courseField = new JTextField();
    private final JTextField gradeField = new JTextField();

    private final JLabel previewId = new JLabel("\u2014");
    private final JLabel previewName = new JLabel("\u2014");
    private final JLabel previewCourse = new JLabel("\u2014");
    private final JLabel previewGrade = new JLabel("\u2014");

    public AddStudentPanel(MainFrame frame, StudentStore store) {
        this.frame = frame;
        this.store = store;

        setLayout(new BorderLayout());
        setBackground(UIStyle.BG);
        setBorder(new EmptyBorder(28, 32, 28, 32));

        JPanel header = new JPanel();
        header.setLayout(new BoxLayout(header, BoxLayout.Y_AXIS));
        header.setBackground(UIStyle.BG);
        header.setAlignmentX(Component.LEFT_ALIGNMENT);
        JLabel title = new JLabel("Add Student");
        title.setFont(UIStyle.FONT_TITLE);
        title.setForeground(UIStyle.TEXT_DARK);
        JLabel subtitle = new JLabel("Fill in the form to register a new student");
        subtitle.setFont(UIStyle.FONT_SUBTITLE);
        subtitle.setForeground(UIStyle.TEXT_GRAY);
        header.add(title);
        header.add(Box.createVerticalStrut(4));
        header.add(subtitle);
        header.setBorder(new EmptyBorder(0, 0, 20, 0));

        JPanel formCard = UIStyle.card();
        formCard.setLayout(new BoxLayout(formCard, BoxLayout.Y_AXIS));

        JLabel formTitle = new JLabel("Student Information");
        formTitle.setFont(UIStyle.FONT_BODY_BOLD);
        formTitle.setAlignmentX(Component.LEFT_ALIGNMENT);
        formCard.add(formTitle);
        formCard.add(Box.createVerticalStrut(14));

        formCard.add(fieldBlock("STUDENT ID / ROLL NUMBER", idField, "e.g. 2024006"));
        formCard.add(Box.createVerticalStrut(12));
        formCard.add(fieldBlock("FULL NAME", nameField, "e.g. Pedro Santos"));
        formCard.add(Box.createVerticalStrut(12));
        formCard.add(fieldBlock("COURSE / PROGRAM", courseField, "e.g. BS Computer Science"));
        formCard.add(Box.createVerticalStrut(12));
        formCard.add(fieldBlock("GRADE (0-100)", gradeField, "e.g. 88"));
        formCard.add(Box.createVerticalStrut(18));

        JPanel buttonRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        buttonRow.setBackground(UIStyle.BG);
        buttonRow.setAlignmentX(Component.LEFT_ALIGNMENT);
        JButton addBtn = UIStyle.primaryButton("Add Student");
        JButton cancelBtn = UIStyle.secondaryButton("Cancel");
        addBtn.addActionListener(e -> onAddStudent());
        cancelBtn.addActionListener(e -> {
            clearForm();
            frame.navigate(MainFrame.RECORDS);
        });
        buttonRow.add(addBtn);
        buttonRow.add(cancelBtn);
        formCard.add(buttonRow);

        // ---- Right column: preview + info ----
        JPanel rightColumn = new JPanel();
        rightColumn.setLayout(new BoxLayout(rightColumn, BoxLayout.Y_AXIS));
        rightColumn.setBackground(UIStyle.BG);

        JPanel previewCard = UIStyle.card();
        previewCard.setLayout(new BoxLayout(previewCard, BoxLayout.Y_AXIS));
        JLabel previewTitle = new JLabel("Preview");
        previewTitle.setFont(UIStyle.FONT_BODY_BOLD);
        previewTitle.setAlignmentX(Component.LEFT_ALIGNMENT);
        previewCard.add(previewTitle);
        previewCard.add(Box.createVerticalStrut(12));
        previewCard.add(previewRow("Student ID", previewId));
        previewCard.add(previewDivider());
        previewCard.add(previewRow("Name", previewName));
        previewCard.add(previewDivider());
        previewCard.add(previewRow("Course", previewCourse));
        previewCard.add(previewDivider());
        previewCard.add(previewRow("Grade", previewGrade));

        JPanel infoCard = new JPanel();
        infoCard.setLayout(new BoxLayout(infoCard, BoxLayout.Y_AXIS));
        infoCard.setBackground(UIStyle.BLUE_LIGHT);
        infoCard.setBorder(new EmptyBorder(14, 14, 14, 14));
        infoCard.setAlignmentX(Component.LEFT_ALIGNMENT);
        JLabel infoTitle = new JLabel("How it works");
        infoTitle.setFont(UIStyle.FONT_BODY_BOLD);
        infoTitle.setForeground(UIStyle.BLUE);
        JTextArea infoBody = new JTextArea(
                "Records are stored in a Binary Search Tree keyed by Student ID. "
                        + "Insert, search, and delete all run in O(log n) time on average "
                        + "by comparing IDs and branching left or right.");
        infoBody.setLineWrap(true);
        infoBody.setWrapStyleWord(true);
        infoBody.setEditable(false);
        infoBody.setOpaque(false);
        infoBody.setFont(new Font("SansSerif", Font.PLAIN, 12));
        infoBody.setForeground(UIStyle.TEXT_DARK);
        infoBody.setBorder(new EmptyBorder(6, 0, 0, 0));
        infoCard.add(infoTitle);
        infoCard.add(infoBody);

        rightColumn.add(previewCard);
        rightColumn.add(Box.createVerticalStrut(16));
        rightColumn.add(infoCard);

        JPanel columns = new JPanel(new GridLayout(1, 2, 20, 0));
        columns.setBackground(UIStyle.BG);
        columns.add(formCard);
        columns.add(rightColumn);

        add(header, BorderLayout.NORTH);
        add(columns, BorderLayout.CENTER);

        DocumentListener liveUpdate = new DocumentListener() {
            public void insertUpdate(DocumentEvent e) { updatePreview(); }
            public void removeUpdate(DocumentEvent e) { updatePreview(); }
            public void changedUpdate(DocumentEvent e) { updatePreview(); }
        };
        idField.getDocument().addDocumentListener(liveUpdate);
        nameField.getDocument().addDocumentListener(liveUpdate);
        courseField.getDocument().addDocumentListener(liveUpdate);
        gradeField.getDocument().addDocumentListener(liveUpdate);
    }

    private JPanel fieldBlock(String label, JTextField field, String placeholder) {
        JPanel block = new JPanel();
        block.setLayout(new BoxLayout(block, BoxLayout.Y_AXIS));
        block.setBackground(UIStyle.BG);
        block.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel l = new JLabel(label);
        l.setFont(UIStyle.FONT_LABEL);
        l.setForeground(UIStyle.TEXT_GRAY);
        l.setAlignmentX(Component.LEFT_ALIGNMENT);

        field.setFont(UIStyle.FONT_BODY);
        field.setBorder(new javax.swing.border.CompoundBorder(
                new javax.swing.border.LineBorder(UIStyle.BORDER, 1, true),
                new EmptyBorder(8, 10, 8, 10)));
        field.setAlignmentX(Component.LEFT_ALIGNMENT);
        field.setMaximumSize(new Dimension(Integer.MAX_VALUE, 36));
        field.putClientProperty("JTextField.placeholderText", placeholder);

        block.add(l);
        block.add(Box.createVerticalStrut(4));
        block.add(field);
        return block;
    }

    private JPanel previewRow(String label, JLabel valueLabel) {
        JPanel row = new JPanel(new BorderLayout());
        row.setBackground(UIStyle.BG);
        row.setBorder(new EmptyBorder(8, 0, 8, 0));
        row.setAlignmentX(Component.LEFT_ALIGNMENT);
        JLabel l = new JLabel(label);
        l.setFont(new Font("SansSerif", Font.PLAIN, 12));
        l.setForeground(UIStyle.TEXT_GRAY);
        valueLabel.setFont(UIStyle.FONT_BODY_BOLD);
        valueLabel.setForeground(UIStyle.TEXT_DARK);
        row.add(l, BorderLayout.WEST);
        row.add(valueLabel, BorderLayout.EAST);
        return row;
    }

    private JSeparator previewDivider() {
        JSeparator sep = new JSeparator();
        sep.setForeground(UIStyle.BORDER);
        sep.setAlignmentX(Component.LEFT_ALIGNMENT);
        return sep;
    }

    private void updatePreview() {
        previewId.setText(idField.getText().isBlank() ? "\u2014" : idField.getText().trim());
        previewName.setText(nameField.getText().isBlank() ? "\u2014" : nameField.getText().trim());
        previewCourse.setText(courseField.getText().isBlank() ? "\u2014" : courseField.getText().trim());
        previewGrade.setText(gradeField.getText().isBlank() ? "\u2014" : gradeField.getText().trim());
    }

    private void onAddStudent() {
        String id = idField.getText().trim();
        String name = nameField.getText().trim();
        String course = courseField.getText().trim();
        String gradeText = gradeField.getText().trim();

        if (id.isEmpty() || name.isEmpty() || course.isEmpty() || gradeText.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill in all fields.",
                    "Missing Information", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int grade;
        try {
            grade = Integer.parseInt(gradeText);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Grade must be a whole number between 0 and 100.",
                    "Invalid Grade", JOptionPane.WARNING_MESSAGE);
            return;
        }
        if (grade < 0 || grade > 100) {
            JOptionPane.showMessageDialog(this, "Grade must be between 0 and 100.",
                    "Invalid Grade", JOptionPane.WARNING_MESSAGE);
            return;
        }

        boolean added = store.addStudent(id, name, course, grade);
        if (!added) {
            JOptionPane.showMessageDialog(this,
                    "A student with ID " + id + " already exists in the records.",
                    "Duplicate Student ID", JOptionPane.ERROR_MESSAGE);
            return;
        }

        JOptionPane.showMessageDialog(this, name + " was added successfully.",
                "Student Added", JOptionPane.INFORMATION_MESSAGE);
        clearForm();
        frame.navigate(MainFrame.RECORDS);
    }

    private void clearForm() {
        idField.setText("");
        nameField.setText("");
        courseField.setText("");
        gradeField.setText("");
        updatePreview();
    }

    @Override
    public void refresh() {
        // form intentionally keeps its state unless explicitly cleared
    }
}

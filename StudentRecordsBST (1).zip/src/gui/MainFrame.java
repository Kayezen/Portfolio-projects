package gui;

import logic.StudentStore;

import javax.swing.*;
import java.awt.*;

/**
 * Top level JFrame. Holds the StudentStore (BST-backed data) and swaps
 * between DashboardPanel, RecordsPanel, and AddStudentPanel using
 * CardLayout, matching the three mockup screens.
 */
public class MainFrame extends JFrame {

    private final StudentStore store = new StudentStore();
    private final JPanel contentWrapper; // sidebar + card area
    private final JPanel cards;
    private final CardLayout cardLayout;

    public static final String DASHBOARD = "DASHBOARD";
    public static final String RECORDS = "RECORDS";
    public static final String ADD = "ADD";

    public MainFrame() {
        super("Student Records Management System");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1100, 700);
        setMinimumSize(new Dimension(900, 600));
        setLocationRelativeTo(null);

        store.loadSampleData();

        cardLayout = new CardLayout();
        cards = new JPanel(cardLayout);
        cards.setBackground(UIStyle.BG);

        cards.add(new DashboardPanel(this, store), DASHBOARD);
        cards.add(new RecordsPanel(this, store), RECORDS);
        cards.add(new AddStudentPanel(this, store), ADD);

        contentWrapper = new JPanel(new BorderLayout());
        rebuildSidebar(DASHBOARD);
        contentWrapper.add(cards, BorderLayout.CENTER);

        setContentPane(contentWrapper);
        cardLayout.show(cards, DASHBOARD);
    }

    private void rebuildSidebar(String active) {
        if (contentWrapper.getComponentCount() > 0) {
            // remove old sidebar if present (index 0 in WEST)
            Component west = null;
            for (Component c : contentWrapper.getComponents()) {
                if (((BorderLayout) contentWrapper.getLayout()).getConstraints(c) == BorderLayout.WEST) {
                    west = c;
                }
            }
            if (west != null) contentWrapper.remove(west);
        }
        Sidebar sidebar = new Sidebar(active, this::navigate);
        contentWrapper.add(sidebar, BorderLayout.WEST);
        contentWrapper.revalidate();
        contentWrapper.repaint();
    }

    /** Called by any panel (or the sidebar) to switch screens. */
    public void navigate(String screen) {
        // Refresh dynamic panels so they show latest data each time they're shown
        for (Component c : cards.getComponents()) {
            if (c instanceof Refreshable) {
                ((Refreshable) c).refresh();
            }
        }
        rebuildSidebar(screen);
        cardLayout.show(cards, screen);
    }

    public interface Refreshable {
        void refresh();
    }
}

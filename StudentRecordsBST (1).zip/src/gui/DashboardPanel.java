package gui;

import logic.Student;
import logic.StudentStore;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.util.List;

/** Dashboard screen: stat cards + recent students list. */
public class DashboardPanel extends JPanel implements MainFrame.Refreshable {

    private final MainFrame frame;
    private final StudentStore store;
    private final JPanel statsRow;
    private final JPanel recentListPanel;

    public DashboardPanel(MainFrame frame, StudentStore store) {
        this.frame = frame;
        this.store = store;

        setLayout(new BorderLayout());
        setBackground(UIStyle.BG);
        setBorder(new EmptyBorder(28, 32, 28, 32));

        JPanel header = new JPanel();
        header.setLayout(new BoxLayout(header, BoxLayout.Y_AXIS));
        header.setBackground(UIStyle.BG);
        header.setAlignmentX(Component.LEFT_ALIGNMENT);
        JLabel title = new JLabel("Dashboard");
        title.setFont(UIStyle.FONT_TITLE);
        title.setForeground(UIStyle.TEXT_DARK);
        JLabel subtitle = new JLabel("Overview of your student records");
        subtitle.setFont(UIStyle.FONT_SUBTITLE);
        subtitle.setForeground(UIStyle.TEXT_GRAY);
        header.add(title);
        header.add(Box.createVerticalStrut(4));
        header.add(subtitle);

        statsRow = new JPanel(new GridLayout(1, 3, 16, 0));
        statsRow.setBackground(UIStyle.BG);
        statsRow.setBorder(new EmptyBorder(20, 0, 20, 0));

        recentListPanel = new JPanel();
        recentListPanel.setLayout(new BoxLayout(recentListPanel, BoxLayout.Y_AXIS));
        recentListPanel.setBackground(UIStyle.BG);

        JPanel recentCard = UIStyle.card();
        recentCard.setLayout(new BorderLayout());

        JPanel recentHeader = new JPanel(new BorderLayout());
        recentHeader.setBackground(UIStyle.BG);
        JPanel recentTitleBlock = new JPanel();
        recentTitleBlock.setLayout(new BoxLayout(recentTitleBlock, BoxLayout.Y_AXIS));
        recentTitleBlock.setBackground(UIStyle.BG);
        JLabel recentTitle = new JLabel("Recent Students");
        recentTitle.setFont(UIStyle.FONT_BODY_BOLD);
        JLabel recentSub = new JLabel("Last 3 added");
        recentSub.setFont(new Font("SansSerif", Font.PLAIN, 11));
        recentSub.setForeground(UIStyle.TEXT_GRAY);
        recentTitleBlock.add(recentTitle);
        recentTitleBlock.add(recentSub);

        JButton viewAll = UIStyle.linkButton("View all \u2192", UIStyle.BLUE);
        viewAll.addActionListener(e -> frame.navigate(MainFrame.RECORDS));

        recentHeader.add(recentTitleBlock, BorderLayout.WEST);
        recentHeader.add(viewAll, BorderLayout.EAST);
        recentHeader.setBorder(new EmptyBorder(0, 0, 12, 0));

        recentCard.add(recentHeader, BorderLayout.NORTH);
        recentCard.add(recentListPanel, BorderLayout.CENTER);

        JPanel actionsRow = new JPanel(new GridLayout(1, 2, 16, 0));
        actionsRow.setBackground(UIStyle.BG);
        actionsRow.setBorder(new EmptyBorder(20, 0, 0, 0));
        JButton addBtn = UIStyle.primaryButton("+ Add Student");
        addBtn.addActionListener(e -> frame.navigate(MainFrame.ADD));
        JButton viewBtn = UIStyle.secondaryButton("View Records");
        viewBtn.addActionListener(e -> frame.navigate(MainFrame.RECORDS));
        actionsRow.add(addBtn);
        actionsRow.add(viewBtn);

        JPanel centerStack = new JPanel();
        centerStack.setLayout(new BoxLayout(centerStack, BoxLayout.Y_AXIS));
        centerStack.setBackground(UIStyle.BG);
        centerStack.add(statsRow);
        centerStack.add(recentCard);
        centerStack.add(actionsRow);

        add(header, BorderLayout.NORTH);
        add(centerStack, BorderLayout.CENTER);

        refresh();
    }

    @Override
    public void refresh() {
        statsRow.removeAll();
        statsRow.add(statCard("\uD83D\uDC65", String.valueOf(store.totalStudents()),
                "Total Students", "enrolled records", UIStyle.BLUE));

        Student top = store.topStudent();
        double avg = store.averageGrade();
        statsRow.add(statCard("\uD83D\uDCC8", String.format("%.1f", avg),
                "Average Grade", "class average", UIStyle.GREEN));

        statsRow.add(statCard("\u2B50", top != null ? String.valueOf(top.grade) : "--",
                "Top Grade", top != null ? top.name : "N/A", UIStyle.AMBER));

        recentListPanel.removeAll();
        List<Student> recent = store.recentStudents();
        if (recent.isEmpty()) {
            JLabel empty = new JLabel("No students added yet.");
            empty.setForeground(UIStyle.TEXT_GRAY);
            empty.setBorder(new EmptyBorder(10, 4, 10, 4));
            recentListPanel.add(empty);
        } else {
            for (int i = 0; i < recent.size(); i++) {
                recentListPanel.add(recentRow(recent.get(i)));
                if (i < recent.size() - 1) {
                    JSeparator sep = new JSeparator();
                    sep.setForeground(UIStyle.BORDER);
                    recentListPanel.add(sep);
                }
            }
        }

        statsRow.revalidate();
        statsRow.repaint();
        recentListPanel.revalidate();
        recentListPanel.repaint();
    }

    private JPanel statCard(String icon, String bigNumber, String label, String sub, Color accent) {
        JPanel card = UIStyle.card();
        card.setLayout(new BorderLayout());

        JLabel iconLabel = new JLabel(icon);
        iconLabel.setFont(new Font("SansSerif", Font.PLAIN, 18));
        JPanel top = new JPanel(new BorderLayout());
        top.setBackground(UIStyle.BG);
        top.add(iconLabel, BorderLayout.EAST);

        JLabel numberLabel = new JLabel(bigNumber);
        numberLabel.setFont(UIStyle.FONT_BIG_NUMBER);
        numberLabel.setForeground(accent);

        JLabel labelLabel = new JLabel(label);
        labelLabel.setFont(UIStyle.FONT_BODY_BOLD);
        labelLabel.setForeground(UIStyle.TEXT_DARK);

        JLabel subLabel = new JLabel(sub);
        subLabel.setFont(new Font("SansSerif", Font.PLAIN, 11));
        subLabel.setForeground(UIStyle.TEXT_GRAY);

        JPanel textStack = new JPanel();
        textStack.setLayout(new BoxLayout(textStack, BoxLayout.Y_AXIS));
        textStack.setBackground(UIStyle.BG);
        textStack.add(numberLabel);
        textStack.add(Box.createVerticalStrut(6));
        textStack.add(labelLabel);
        textStack.add(subLabel);

        card.add(top, BorderLayout.NORTH);
        card.add(textStack, BorderLayout.CENTER);
        return card;
    }

    private JPanel recentRow(Student s) {
        JPanel row = new JPanel(new BorderLayout(12, 0));
        row.setBackground(UIStyle.BG);
        row.setBorder(new EmptyBorder(10, 4, 10, 4));

        JLabel avatar = UIStyle.avatar(s.name);

        JPanel textStack = new JPanel();
        textStack.setLayout(new BoxLayout(textStack, BoxLayout.Y_AXIS));
        textStack.setBackground(UIStyle.BG);
        JLabel nameLabel = new JLabel(s.name);
        nameLabel.setFont(UIStyle.FONT_BODY_BOLD);
        JLabel courseLabel = new JLabel(s.course);
        courseLabel.setFont(new Font("SansSerif", Font.PLAIN, 11));
        courseLabel.setForeground(UIStyle.TEXT_GRAY);
        textStack.add(nameLabel);
        textStack.add(courseLabel);

        JPanel left = new JPanel(new BorderLayout(12, 0));
        left.setBackground(UIStyle.BG);
        left.add(avatar, BorderLayout.WEST);
        left.add(textStack, BorderLayout.CENTER);

        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        right.setBackground(UIStyle.BG);
        JLabel idLabel = new JLabel(s.studentId);
        idLabel.setForeground(UIStyle.TEXT_GRAY);
        idLabel.setFont(UIStyle.FONT_BODY);
        JLabel gradePill = UIStyle.pill(String.valueOf(s.grade),
                UIStyle.gradeColor(s.grade), UIStyle.gradeColorBg(s.grade));
        right.add(idLabel);
        right.add(gradePill);

        row.add(left, BorderLayout.CENTER);
        row.add(right, BorderLayout.EAST);
        return row;
    }
}
